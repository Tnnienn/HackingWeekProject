import java.util.ArrayList;
import java.util.Collections;

public class main {

    public static void main(String[] args) {

        Position position1 = new Position(1,2);
        Position position2 = new Position(3,4);
        Position position3 = new Position(2,3);

        ArrayList<Position> position = new ArrayList<>();

        position.add(position1);
        position.add(position2);
        position.add(position3);

        Collections.sort(position);

        System.out.println(position);
    }
}
